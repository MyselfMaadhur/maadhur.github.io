import Navigation from './components/Navigation';
import HeroSection from './components/HeroSection';
import SubjectsGrid from './components/SubjectsGrid';
import StudyTracker from './components/StudyTracker';
import ResourcesSection from './components/ResourcesSection';
import Footer from './components/Footer';

function App() {
  return (
    <div className="min-h-screen" style={{ background: '#0A0B0E' }}>
      <Navigation />
      <HeroSection />
      <SubjectsGrid />
      <StudyTracker />
      <ResourcesSection />
      <Footer />
    </div>
  );
}

export default App;
