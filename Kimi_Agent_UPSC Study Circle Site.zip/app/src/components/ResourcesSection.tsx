import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import { Calendar, FileText, Scroll, BookMarked } from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const resources = [
  {
    icon: Calendar,
    title: 'Study Planner',
    description: 'Create and manage your daily study schedule',
    accent: '#FF4D8B',
    glowShadow: '0 0 30px rgba(255, 77, 139, 0.25)',
  },
  {
    icon: FileText,
    title: 'Syllabus',
    description: 'Complete UPSC syllabus with topic breakdown',
    accent: '#00D4FF',
    glowShadow: '0 0 30px rgba(0, 212, 255, 0.25)',
  },
  {
    icon: Scroll,
    title: 'Previous Year Papers',
    description: 'Access solved papers from last 10 years',
    accent: '#8B5CF6',
    glowShadow: '0 0 30px rgba(139, 92, 246, 0.25)',
  },
  {
    icon: BookMarked,
    title: 'Study Notes',
    description: 'Comprehensive notes for all subjects',
    accent: '#22C55E',
    glowShadow: '0 0 30px rgba(34, 197, 94, 0.25)',
  },
];

export default function ResourcesSection() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    // Title text reveal
    if (titleRef.current) {
      const text = 'Study Resources';
      titleRef.current.innerHTML = '';
      const chars: HTMLSpanElement[] = [];
      for (const char of text) {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        titleRef.current.appendChild(span);
        chars.push(span);
      }

      ScrollTrigger.create({
        trigger: titleRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo(chars,
            { opacity: 0, x: 20 },
            { opacity: 1, x: 0, stagger: 0.03, duration: 0.8, ease: 'back.out(1.7)' }
          );
        },
        once: true,
      });
    }

    // Subtitle
    if (subtitleRef.current) {
      gsap.set(subtitleRef.current, { opacity: 0, y: 30 });
      ScrollTrigger.create({
        trigger: subtitleRef.current,
        start: 'top 90%',
        onEnter: () => {
          gsap.to(subtitleRef.current, { opacity: 1, y: 0, duration: 0.8, delay: 0.2, ease: 'power2.out' });
        },
        once: true,
      });
    }

    // Cards entrance + 3D tilt
    cardsRef.current.forEach((card, index) => {
      if (!card) return;

      gsap.set(card, { opacity: 0, y: 50 });
      ScrollTrigger.create({
        trigger: card,
        start: 'top 95%',
        onEnter: () => {
          gsap.to(card, { opacity: 1, y: 0, duration: 0.8, delay: index * 0.15, ease: 'power2.out' });
        },
        once: true,
      });

      // 3D tilt
      const handleMouseMove = (e: MouseEvent) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -5;
        const rotateY = ((x - centerX) / centerX) * 5;

        gsap.to(card, { rotateX, rotateY, scale: 1.03, duration: 0.4, ease: 'power2.out' });
      };

      const handleMouseLeave = () => {
        gsap.to(card, { rotateX: 0, rotateY: 0, scale: 1, duration: 0.6, ease: 'power2.out' });
      };

      card.addEventListener('mousemove', handleMouseMove);
      card.addEventListener('mouseleave', handleMouseLeave);
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="resources"
      className="relative py-[120px] md:py-[80px]"
      style={{ background: '#0C0C0E' }}
    >
      <div className="max-w-[1200px] mx-auto px-6">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2
            ref={titleRef}
            className="text-[#F0F0F5] font-extrabold"
            style={{ fontSize: 'clamp(28px, 4vw, 48px)', lineHeight: 1.15 }}
          >
            Study Resources
          </h2>
          <p
            ref={subtitleRef}
            className="text-[#8A8B96] text-base mt-3 max-w-[500px] mx-auto"
          >
            Curated resources to boost your UPSC preparation
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
          {resources.map((resource, index) => {
            const Icon = resource.icon;
            return (
              <div
                key={resource.title}
                ref={(el) => { cardsRef.current[index] = el; }}
                className="liquid-glass liquid-glass-resource rounded-[20px] p-7 text-center relative group"
                style={{
                  transformStyle: 'preserve-3d',
                  willChange: 'transform',
                  cursor: 'pointer',
                }}
              >
                {/* Icon */}
                <div
                  className="w-16 h-16 rounded-2xl flex items-center justify-center mx-auto mb-4 transition-transform duration-300 group-hover:scale-110"
                  style={{
                    background: `linear-gradient(135deg, ${resource.accent}22, ${resource.accent}11)`,
                  }}
                >
                  <Icon size={32} style={{ color: resource.accent }} />
                </div>

                {/* Title */}
                <h3 className="text-[#F0F0F5] font-bold text-lg mb-2">
                  {resource.title}
                </h3>

                {/* Description */}
                <p className="text-[#8A8B96] text-sm leading-relaxed">
                  {resource.description}
                </p>

                {/* Hover glow */}
                <div
                  className="absolute inset-0 rounded-[20px] pointer-events-none opacity-0 transition-opacity duration-400 group-hover:opacity-100"
                  style={{ boxShadow: resource.glowShadow }}
                />
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
