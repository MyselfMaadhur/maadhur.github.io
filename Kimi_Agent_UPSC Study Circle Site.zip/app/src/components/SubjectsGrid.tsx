import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import {
  BookOpen, Globe, Landmark, TrendingUp, Leaf, Atom,
  Newspaper, Heart, Palette, Handshake, ShieldAlert, Shield
} from 'lucide-react';

gsap.registerPlugin(ScrollTrigger);

const subjects = [
  {
    name: 'History',
    icon: BookOpen,
    gradient: 'from-[#FF4D8B] to-[#FF6B9F]',
    glowColor: 'rgba(255, 77, 139, 0.3)',
    description: 'Ancient, Medieval & Modern Indian History',
  },
  {
    name: 'Geography',
    icon: Globe,
    gradient: 'from-[#00D4FF] to-[#33DFFF]',
    glowColor: 'rgba(0, 212, 255, 0.3)',
    description: 'Physical, Human & Indian Geography',
  },
  {
    name: 'Polity',
    icon: Landmark,
    gradient: 'from-[#8B5CF6] to-[#A78BFA]',
    glowColor: 'rgba(139, 92, 246, 0.3)',
    description: 'Constitution, Governance & Politics',
  },
  {
    name: 'Economy',
    icon: TrendingUp,
    gradient: 'from-[#22C55E] to-[#4ADE80]',
    glowColor: 'rgba(34, 197, 94, 0.3)',
    description: 'Indian Economy & Economic Development',
  },
  {
    name: 'Environment',
    icon: Leaf,
    gradient: 'from-[#FF4D8B] to-[#FF6B9F]',
    glowColor: 'rgba(255, 77, 139, 0.3)',
    description: 'Ecology, Biodiversity & Climate Change',
  },
  {
    name: 'Science & Tech',
    icon: Atom,
    gradient: 'from-[#00D4FF] to-[#33DFFF]',
    glowColor: 'rgba(0, 212, 255, 0.3)',
    description: 'General Science & Technology Developments',
  },
  {
    name: 'Current Affairs',
    icon: Newspaper,
    gradient: 'from-[#8B5CF6] to-[#A78BFA]',
    glowColor: 'rgba(139, 92, 246, 0.3)',
    description: 'National & International Current Events',
  },
  {
    name: 'Ethics',
    icon: Heart,
    gradient: 'from-[#22C55E] to-[#4ADE80]',
    glowColor: 'rgba(34, 197, 94, 0.3)',
    description: 'Integrity, Aptitude & Ethics in Governance',
  },
  {
    name: 'Art & Culture',
    icon: Palette,
    gradient: 'from-[#FF4D8B] to-[#FF6B9F]',
    glowColor: 'rgba(255, 77, 139, 0.3)',
    description: 'Indian Heritage, Art Forms & Culture',
  },
  {
    name: 'International Relations',
    icon: Handshake,
    gradient: 'from-[#00D4FF] to-[#33DFFF]',
    glowColor: 'rgba(0, 212, 255, 0.3)',
    description: "India's Foreign Policy & Global Relations",
  },
  {
    name: 'Disaster Management',
    icon: ShieldAlert,
    gradient: 'from-[#8B5CF6] to-[#A78BFA]',
    glowColor: 'rgba(139, 92, 246, 0.3)',
    description: 'Disaster Preparedness & Risk Reduction',
  },
  {
    name: 'Internal Security',
    icon: Shield,
    gradient: 'from-[#FF4D8B] to-[#FF6B9F]',
    glowColor: 'rgba(255, 77, 139, 0.3)',
    description: 'Internal Security Challenges & Solutions',
  },
];

export default function SubjectsGrid() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);

  useEffect(() => {
    // Title text reveal
    if (titleRef.current) {
      const text = 'All UPSC Subjects';
      titleRef.current.innerHTML = '';
      const chars: HTMLSpanElement[] = [];
      for (const char of text) {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        titleRef.current.appendChild(span);
        chars.push(span);
      }

      ScrollTrigger.create({
        trigger: titleRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo(chars,
            { opacity: 0, x: 20 },
            { opacity: 1, x: 0, stagger: 0.03, duration: 0.8, ease: 'back.out(1.7)' }
          );
        },
        once: true,
      });
    }

    // Subtitle reveal
    if (subtitleRef.current) {
      gsap.set(subtitleRef.current, { opacity: 0, y: 30 });
      ScrollTrigger.create({
        trigger: subtitleRef.current,
        start: 'top 90%',
        onEnter: () => {
          gsap.to(subtitleRef.current, { opacity: 1, y: 0, duration: 0.8, delay: 0.2, ease: 'power2.out' });
        },
        once: true,
      });
    }

    // Cards staggered reveal + 3D tilt
    cardsRef.current.forEach((card, index) => {
      if (!card) return;

      // Entrance animation
      gsap.set(card, { opacity: 0, y: 50 });
      ScrollTrigger.create({
        trigger: card,
        start: 'top 95%',
        onEnter: () => {
          gsap.to(card, { opacity: 1, y: 0, duration: 0.8, delay: index * 0.1, ease: 'power2.out' });
        },
        once: true,
      });

      // 3D Tilt on hover
      const handleMouseMove = (e: MouseEvent) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -8;
        const rotateY = ((x - centerX) / centerX) * 8;

        gsap.to(card, {
          rotateX,
          rotateY,
          scale: 1.03,
          duration: 0.4,
          ease: 'power2.out',
        });

        // Update glow position
        const glow = card.querySelector('.card-glow') as HTMLElement;
        if (glow) {
          const glowX = (x / rect.width) * 100;
          const glowY = (y / rect.height) * 100;
          glow.style.background = `radial-gradient(circle at ${glowX}% ${glowY}%, ${subjects[index].glowColor}, transparent 70%)`;
          glow.style.opacity = '0.4';
        }
      };

      const handleMouseLeave = () => {
        gsap.to(card, {
          rotateX: 0,
          rotateY: 0,
          scale: 1,
          duration: 0.6,
          ease: 'power2.out',
        });

        const glow = card.querySelector('.card-glow') as HTMLElement;
        if (glow) {
          glow.style.opacity = '0';
        }
      };

      card.addEventListener('mousemove', handleMouseMove);
      card.addEventListener('mouseleave', handleMouseLeave);
    });

    return () => {
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="subjects"
      className="relative py-[120px] md:py-[80px]"
      style={{ background: '#0C0C0E' }}
    >
      {/* Ambient glow decorations */}
      <div className="absolute top-20 left-10 w-[400px] h-[400px] rounded-full pointer-events-none opacity-30"
        style={{ background: 'radial-gradient(circle, rgba(255, 77, 139, 0.03), transparent 70%)' }} />
      <div className="absolute bottom-20 right-10 w-[400px] h-[400px] rounded-full pointer-events-none opacity-30"
        style={{ background: 'radial-gradient(circle, rgba(0, 212, 255, 0.03), transparent 70%)' }} />
      <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] rounded-full pointer-events-none opacity-20"
        style={{ background: 'radial-gradient(circle, rgba(139, 92, 246, 0.03), transparent 70%)' }} />

      <div className="max-w-[1200px] mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-16">
          <h2
            ref={titleRef}
            className="text-[#F0F0F5] font-extrabold"
            style={{ fontSize: 'clamp(32px, 5vw, 56px)', lineHeight: 1.15 }}
          >
            All UPSC Subjects
          </h2>
          <p
            ref={subtitleRef}
            className="text-[#8A8B96] text-base mt-3 max-w-[600px] mx-auto"
          >
            Comprehensive coverage of every subject in the UPSC Civil Services Examination syllabus
          </p>
        </div>

        {/* Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 max-w-[800px] mx-auto">
          {subjects.map((subject, index) => {
            const Icon = subject.icon;
            return (
              <div
                key={subject.name}
                ref={(el) => { cardsRef.current[index] = el; }}
                className="subject-card flex items-center gap-5"
                style={{ '--glow-color': subject.glowColor } as React.CSSProperties}
              >
                <div className="card-glow" />

                {/* Circle Icon */}
                <div
                  className={`w-20 h-20 rounded-full flex items-center justify-center flex-shrink-0 bg-gradient-to-br ${subject.gradient}`}
                  style={{
                    boxShadow: `0 0 20px ${subject.glowColor.replace('0.3', '0.2')}`,
                  }}
                >
                  <Icon size={32} className="text-white" />
                </div>

                {/* Text */}
                <div className="text-left">
                  <h3 className="text-[#F0F0F5] font-bold text-xl mb-1">
                    {subject.name}
                  </h3>
                  <p className="text-[#8A8B96] text-sm leading-relaxed line-clamp-2">
                    {subject.description}
                  </p>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
