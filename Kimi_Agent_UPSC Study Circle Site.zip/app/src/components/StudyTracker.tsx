import { useEffect, useRef } from 'react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';
import CountUp from 'react-countup';

gsap.registerPlugin(ScrollTrigger);

const trackers = [
  { number: 4.5, suffix: '', label: 'Hours Today', color: '#FF4D8B', glowShadow: '0 0 30px rgba(255, 77, 139, 0.25)' },
  { number: 35, suffix: '', label: 'Hours This Week', color: '#00D4FF', glowShadow: '0 0 30px rgba(0, 212, 255, 0.25)' },
  { number: 12, suffix: '', label: 'Day Streak', color: '#8B5CF6', glowShadow: '0 0 30px rgba(139, 92, 246, 0.25)' },
];

/* ---------- Dot Grid Canvas ---------- */
function initDotGrid(canvas: HTMLCanvasElement) {
  const ctx = canvas.getContext('2d');
  if (!ctx) return null;

  const dpr = Math.min(window.devicePixelRatio, 2);
  let w = 0, h = 0;
  let mouseX = -1000, mouseY = -1000;
  let targetMouseX = -1000, targetMouseY = -1000;

  function resize() {
    const parent = canvas.parentElement;
    if (!parent) return;
    w = parent.clientWidth;
    h = parent.clientHeight;
    canvas.width = w * dpr;
    canvas.height = h * dpr;
    ctx!.setTransform(dpr, 0, 0, dpr, 0, 0);
  }
  resize();

  const handleMouseMove = (e: MouseEvent) => {
    const rect = canvas.getBoundingClientRect();
    targetMouseX = e.clientX - rect.left;
    targetMouseY = e.clientY - rect.top;
  };

  const handleMouseLeave = () => {
    targetMouseX = -1000;
    targetMouseY = -1000;
  };

  canvas.addEventListener('mousemove', handleMouseMove);
  canvas.addEventListener('mouseleave', handleMouseLeave);

  let rafId: number;

  function draw() {
    mouseX += (targetMouseX - mouseX) * 0.1;
    mouseY += (targetMouseY - mouseY) * 0.1;

    ctx!.clearRect(0, 0, w, h);

    const spacing = 20;
    for (let x = 0; x < w; x += spacing) {
      for (let y = 0; y < h; y += spacing) {
        const dx = x - mouseX;
        const dy = y - mouseY;
        const dist = Math.sqrt(dx * dx + dy * dy);
        const radius = 150;

        let r = 1;
        let colorVal = 51;

        if (dist < radius) {
          const brightness = 1 - Math.pow(dist / radius, 2);
          r = 1 + 0.5 * brightness;
          colorVal = Math.floor(51 + 17 * brightness);
        }

        ctx!.beginPath();
        ctx!.arc(x, y, r, 0, Math.PI * 2);

        if (dist < 50) {
          ctx!.shadowBlur = 6;
          ctx!.shadowColor = 'rgba(255, 255, 255, 0.15)';
        } else {
          ctx!.shadowBlur = 0;
        }

        ctx!.fillStyle = `rgb(${colorVal}, ${colorVal}, ${colorVal})`;
        ctx!.fill();
      }
    }

    ctx!.shadowBlur = 0;
    rafId = requestAnimationFrame(draw);
  }
  draw();

  window.addEventListener('resize', resize);

  return {
    destroy() {
      cancelAnimationFrame(rafId);
      canvas.removeEventListener('mousemove', handleMouseMove);
      canvas.removeEventListener('mouseleave', handleMouseLeave);
      window.removeEventListener('resize', resize);
    }
  };
}

export default function StudyTracker() {
  const sectionRef = useRef<HTMLElement>(null);
  const titleRef = useRef<HTMLHeadingElement>(null);
  const subtitleRef = useRef<HTMLParagraphElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const cardsRef = useRef<(HTMLDivElement | null)[]>([]);
  const countUpTriggered = useRef(false);

  useEffect(() => {
    const canvas = canvasRef.current;
    let dotGrid: { destroy: () => void } | null = null;
    if (canvas) {
      dotGrid = initDotGrid(canvas);
    }

    // Title text reveal
    if (titleRef.current) {
      const text = 'Track Your Progress';
      titleRef.current.innerHTML = '';
      const chars: HTMLSpanElement[] = [];
      for (const char of text) {
        const span = document.createElement('span');
        span.textContent = char === ' ' ? '\u00A0' : char;
        span.style.display = 'inline-block';
        span.style.opacity = '0';
        titleRef.current.appendChild(span);
        chars.push(span);
      }

      ScrollTrigger.create({
        trigger: titleRef.current,
        start: 'top 85%',
        onEnter: () => {
          gsap.fromTo(chars,
            { opacity: 0, x: 20 },
            { opacity: 1, x: 0, stagger: 0.03, duration: 0.8, ease: 'back.out(1.7)' }
          );
        },
        once: true,
      });
    }

    // Subtitle
    if (subtitleRef.current) {
      gsap.set(subtitleRef.current, { opacity: 0, y: 30 });
      ScrollTrigger.create({
        trigger: subtitleRef.current,
        start: 'top 90%',
        onEnter: () => {
          gsap.to(subtitleRef.current, { opacity: 1, y: 0, duration: 0.8, delay: 0.2, ease: 'power2.out' });
        },
        once: true,
      });
    }

    // Cards entrance + count trigger
    cardsRef.current.forEach((card, index) => {
      if (!card) return;

      gsap.set(card, { opacity: 0, y: 50 });
      ScrollTrigger.create({
        trigger: card,
        start: 'top 95%',
        onEnter: () => {
          gsap.to(card, { opacity: 1, y: 0, duration: 0.8, delay: index * 0.2, ease: 'power2.out' });
          if (!countUpTriggered.current) {
            countUpTriggered.current = true;
          }
        },
        once: true,
      });

      // 3D tilt (lighter)
      const handleMouseMove = (e: MouseEvent) => {
        const rect = card.getBoundingClientRect();
        const x = e.clientX - rect.left;
        const y = e.clientY - rect.top;
        const centerX = rect.width / 2;
        const centerY = rect.height / 2;
        const rotateX = ((y - centerY) / centerY) * -4;
        const rotateY = ((x - centerX) / centerX) * 4;

        gsap.to(card, { rotateX, rotateY, scale: 1.02, duration: 0.4, ease: 'power2.out' });
      };

      const handleMouseLeave = () => {
        gsap.to(card, { rotateX: 0, rotateY: 0, scale: 1, duration: 0.6, ease: 'power2.out' });
      };

      card.addEventListener('mousemove', handleMouseMove);
      card.addEventListener('mouseleave', handleMouseLeave);
    });

    return () => {
      dotGrid?.destroy();
      ScrollTrigger.getAll().forEach(st => st.kill());
    };
  }, []);

  return (
    <section
      ref={sectionRef}
      id="tracker"
      className="relative py-[120px] md:py-[80px] overflow-hidden"
      style={{ background: '#0A0B0E' }}
    >
      {/* Dot Grid Canvas */}
      <canvas
        ref={canvasRef}
        className="absolute inset-0 w-full h-full pointer-events-auto"
        style={{ zIndex: 0 }}
      />

      <div className="max-w-[1200px] mx-auto px-6 relative z-10">
        {/* Section Header */}
        <div className="text-center mb-12">
          <h2
            ref={titleRef}
            className="text-[#F0F0F5] font-extrabold"
            style={{ fontSize: 'clamp(28px, 4vw, 48px)', lineHeight: 1.15 }}
          >
            Track Your Progress
          </h2>
          <p
            ref={subtitleRef}
            className="text-[#8A8B96] text-base mt-3 max-w-[500px] mx-auto"
          >
            Monitor your daily study hours and stay consistent with your preparation
          </p>
        </div>

        {/* Cards */}
        <div className="flex flex-wrap gap-6 justify-center">
          {trackers.map((tracker, index) => (
            <div
              key={tracker.label}
              ref={(el) => { cardsRef.current[index] = el; }}
              className="liquid-glass liquid-glass-tracker w-[240px] text-center rounded-[20px] relative"
              style={{
                padding: '32px 24px',
                transformStyle: 'preserve-3d',
                willChange: 'transform',
              }}
            >
              {/* Number */}
              <div
                className="text-[#F0F0F5] font-bold"
                style={{ fontFamily: "'JetBrains Mono', monospace", fontSize: '48px', lineHeight: 1 }}
              >
                <CountUp
                  end={tracker.number}
                  duration={2.5}
                  decimals={tracker.number % 1 !== 0 ? 1 : 0}
                  enableScrollSpy
                  scrollSpyOnce
                />
              </div>

              {/* Accent Line */}
              <div
                className="w-10 h-0.5 rounded-full mx-auto mt-4 mb-3"
                style={{ background: tracker.color }}
              />

              {/* Label */}
              <div className="text-[#8A8B96] font-medium text-sm">
                {tracker.label}
              </div>

              {/* Hover glow overlay */}
              <div
                className="absolute inset-0 rounded-[20px] pointer-events-none opacity-0 transition-opacity duration-400"
                style={{
                  boxShadow: tracker.glowShadow,
                }}
                onMouseEnter={(e) => { (e.target as HTMLElement).style.opacity = '1'; }}
                onMouseLeave={(e) => { (e.target as HTMLElement).style.opacity = '0'; }}
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
